public class Main {
    public static void main(String[] args) {

        //3 objetos , 1 estudianete, docente, administrativo
   // hernecia, uso de una clase, en la creacion de objetos
        //Primer objeto. Estudiente1
        Persona estudiante = new Persona(15, "Maria", "Ortiz", 15.78);
        System.out.println( "Nombre: " + estudiante.getNombre()+"\n"+
                            "Apellido: "+ estudiante.getApellido()+"\n"+
                            "Edad: "+estudiante.getEdad()+"\n"+
                            "Id: "+estudiante.getId()+"\n"
        );
        //Metodo1
        estudiante.mostrarNombre("Maria","Ortiz");
        //Metodo 2
        estudiante.grado(15);
        System.out.println("");

        //Segundo objeto.Estudiante 2
        Persona estudiante2 = new Persona(6, "Fernanda", "Correa", 16.78);
        System.out.println( "Nombre: " + estudiante2.getNombre()+"\n"+
                "Apellido: "+ estudiante2.getApellido()+"\n"+
                "Edad: "+estudiante2.getEdad()+"\n"+
                "Id: "+estudiante2.getId()+"\n"
        );
        //Metodo 1
        estudiante2.mostrarNombre("Fernanda","Correa");
        //Metodo 2
        estudiante.grado(6);
        System.out.println("");

        //Tercer objeto. Administrativo
        Persona administrativo=new Persona(30,"Paula","Jaramillo",12.3);
        System.out.println( "Nombre: " + administrativo.getNombre()+"\n"+
                "Apellido: "+ administrativo.getApellido()+"\n"+
                "Edad: "+administrativo.getEdad()+"\n"+
                "Id: "+administrativo.getId()+"\n"
        );
        //Metodo 1
        administrativo.mostrarNombre("Paula","Jaramillo");
        //Metodo 3
        System.out.println("Cargo dentro de la institucion:");administrativo.categoria(12.3);

        //Cuarto objeto. Profesor
        Persona profesor=new Persona(40,"Pedro","Lopez",11.9);
        System.out.println( "Nombre: " + profesor.getNombre()+"\n"+
                "Apellido: "+ profesor.getApellido()+"\n"+
                "Edad: "+profesor.getEdad()+"\n"+
                "Id: "+profesor.getId()+"\n"
        );
        //Metodo1
        profesor.mostrarNombre("Pedro","Lopez");
        //Metodo 4
        System.out.println("Asignatura que dicta el profesor ");profesor.materia("lopez");





    }

}