public class Persona {
    // Abstraccion, contruir los atributos y los metodos de la clase
    // Encapsulamiento , como son atributos puplicos pueden ser llamados desde afuera de la clase
    int edad ;
    String nombre;
    String apellido;
    double id;

    public Persona() {
    }

    public Persona(int edad, String nombre, String apellido, double id) {
        this.edad = edad;
        this.nombre = nombre;
        this.apellido = apellido;
        this.id = id;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public double getId() {
        return id;
    }

    public void setId(double id) {
        this.id = id;
    }

    public void mostrarNombre(String nombre,String apellido){
        System.out.println("Mi nombre es "+ nombre+" "+ apellido);
    }
    public void categoria (double id ){
        if (id== 12.3){
            System.out.println("Es administrador ");
        }else{
            System.out.println("Personal no admitido");
        }
    }
    public void grado(int edad){

        if (edad>11){
            System.out.println("Soy de secuandaria ");
        }else{
            System.out.println("Soy de primaria ");
        }

    }

    public void materia(String apellido){
        if (apellido=="lopez"){
            System.out.println("Profesor de Biologia");
        }
    }



}
